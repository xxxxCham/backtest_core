# Rapport Backtest

- Run ID: `bollinger_atr_BTCUSDC_30m_20260212_034213_71415a57`
- Stratégie: **BollingerATR**
- Symbole: **BTCUSDC**
- Timeframe: **30m**
- Période: 2018-12-15 03:00:00+00:00 → 2026-02-10 22:30:00+00:00
- Trades: 56

## Métriques clés

- Return %: -40.78%
- Sharpe: -1.46
- Max DD %: -40.78%